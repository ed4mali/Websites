TowDesk — Ubernyx Gear evaluation sample

Extract this archive and open index.html in a modern browser. No installation is required. This is a limited browser-based sample, not the full application or a Windows installer. Sample records reset when the page reloads. No data is uploaded. For the full application, licensing, pricing, and delivery requirements, submit an inquiry through Ubernyx Gear.
